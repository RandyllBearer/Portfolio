
package videoengine;

/**
 * A television episode in the video engine.
 */
public interface TvEpisode extends Video {

}

