public class Banana {

    private int _tosses = 0;

    public Banana() {
	
    }

}
