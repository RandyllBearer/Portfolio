public class NoIdException extends Exception {

}
